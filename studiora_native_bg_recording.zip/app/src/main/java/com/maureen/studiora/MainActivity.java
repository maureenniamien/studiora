package com.maureen.studiora;

import android.Manifest;
import androidx.activity.OnBackPressedCallback;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends BridgeActivity {

    private static final String TAG = "StudioraMain";
    private static final int MIC_PERMISSION_CODE = 2001;
    private static final int STORAGE_PERMISSION_CODE = 2002;
    private File nativeRecDir;

    // AJOUT (2026-09-19) : voir TranscriptionRecordingService — capte la fin
    // d'un enregistrement de transcription (fichier prêt ou erreur), qu'il
    // ait été arrêté depuis l'app ou depuis la notification.
    private final BroadcastReceiver recordingStoppedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String file = intent.getStringExtra(TranscriptionRecordingService.EXTRA_FILE);
            String error = intent.getStringExtra(TranscriptionRecordingService.EXTRA_ERROR);
            // Le Service a déjà écrit la même info dans SharedPreferences (pour le
            // cas où ce receiver ne serait pas encore enregistré) ; on la retire
            // ici pour qu'onResume() ne la retraite pas une seconde fois.
            getSharedPreferences(TranscriptionRecordingService.PREFS_NAME, MODE_PRIVATE)
                    .edit().remove(TranscriptionRecordingService.KEY_PENDING_FILE)
                    .remove(TranscriptionRecordingService.KEY_PENDING_ERROR).apply();
            if (file != null) {
                runJs("window.onNativeRecordingReady && window.onNativeRecordingReady(" + org.json.JSONObject.quote(file) + ");");
            } else if (error != null) {
                runJs("window.onNativeRecordingError && window.onNativeRecordingError(" + org.json.JSONObject.quote(error) + ");");
            }
        }
    };
    private Intent pendingIntent = null;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private Handler sttTimeoutHandler;
    private Runnable sttTimeoutRunnable;
    private static final long STT_TIMEOUT_MS = 12000;
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();

    private static final String LIVE_INDEX_URL = "https://maureenniamien.github.io/studiora/index.html";
    private static final String ASSET_DOMAIN = "appassets.androidplatform.net";

    // ── Connexion Google ──
    private static final String GOOGLE_WEB_CLIENT_ID = "156231140819-s7vsf98sf8r22gqfj5l7q7pno0lji19q.apps.googleusercontent.com";
    private static final int RC_GOOGLE_SIGN_IN = 9001;
    private GoogleSignInClient googleSignInClient;

    private class GoogleAuthInterface {
        @JavascriptInterface
        public void signIn() {
            runOnUiThread(() -> {
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(GOOGLE_WEB_CLIENT_ID)
                        .requestEmail()
                        .build();
                googleSignInClient = GoogleSignIn.getClient(MainActivity.this, gso);
                startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE_SIGN_IN);
            });
        }
    }

    private void postGoogleAuthResult(String idToken, boolean success, String error) {
        String js = "window.onGoogleAuthResult && window.onGoogleAuthResult("
                + (idToken == null ? "null" : "\"" + idToken.replace("\"", "\\\"") + "\"") + ", "
                + success + ", "
                + (error == null ? "null" : "\"" + error.replace("\"", "\\\"") + "\"")
                + ");";
        runJs(js);
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    // Correctif natif langues : convertit un tag BCP47 (ex. "en-US", venant de
    // getLanguageLocale() côté JS) en Locale Android. Retombe sur le français
    // si le tag est vide/invalide, pour ne jamais casser l'usage par défaut
    // (chat, cours) qui n'envoie aucune locale.
    private Locale localeFromTag(String tag) {
        if (tag == null || tag.trim().isEmpty()) return new Locale("fr", "FR");
        try {
            Locale l = Locale.forLanguageTag(tag);
            if (l != null && l.getLanguage() != null && !l.getLanguage().isEmpty()) return l;
        } catch (Exception ignored) {}
        return new Locale("fr", "FR");
    }

    private class WebAppInterface {
        @JavascriptInterface
        public void speak(String text) {
            speak(text, null);
        }

        // Correctif natif langues : variante avec locale (ex. "en-US") pour
        // l'entraînement à la prononciation des spécialisations langues.
        // Sans locale (appel à 1 argument ci-dessus, utilisé partout ailleurs
        // dans l'app : chat, cours...), on repasse explicitement en français à
        // chaque appel pour ne jamais laisser le moteur TTS "coincé" dans une
        // langue étrangère après une session de prononciation.
        @JavascriptInterface
        public void speak(String text, String lang) {
            if (tts == null || text == null || text.isEmpty()) return;
            new Handler(Looper.getMainLooper()).post(() -> {
                Locale target = localeFromTag(lang);
                int result = tts.setLanguage(target);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Voix non installée pour cette langue sur l'appareil : on
                    // parle quand même, en français, plutôt que de rester muet.
                    tts.setLanguage(new Locale("fr", "FR"));
                }
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "studiora_tts");
            });
        }

        @JavascriptInterface
        public void stop() {
            new Handler(Looper.getMainLooper()).post(() -> {
                if (tts != null) tts.stop();
            });
        }

        @JavascriptInterface
        public void startListening() {
            new Handler(Looper.getMainLooper()).post(() -> startNativeListening(null));
        }

        // Correctif natif langues : variante avec locale (ex. "en-US") pour
        // reconnaître la voix de l'élève dans la langue de la spécialisation
        // au lieu du français par défaut.
        @JavascriptInterface
        public void startListening(String lang) {
            new Handler(Looper.getMainLooper()).post(() -> startNativeListening(lang));
        }

        @JavascriptInterface
        public void stopListening() {
            new Handler(Looper.getMainLooper()).post(() -> {
                cancelSttTimeout();
                if (speechRecognizer != null) speechRecognizer.stopListening();
            });
        }
    }

    private class DownloadInterface {
        @JavascriptInterface
        public void saveFile(String reqId, String base64Data, String filename, String mimeType) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.NO_WRAP);
                    writeBytesToDownloads(reqId, bytes, filename, mimeType);
                } catch (Exception e) {
                    Log.e(TAG, "saveFile error", e);
                    notifyDownloadResult(reqId, false, safeMsg(e));
                }
            });
        }

        @JavascriptInterface
        public void saveFileFromUrl(String reqId, String url, String filename, String mimeType) {
            downloadExecutor.execute(() -> {
                HttpURLConnection conn = null;
                try {
                    URL u = new URL(url);
                    conn = (HttpURLConnection) u.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(30000);
                    conn.setRequestMethod("GET");
                    conn.connect();

                    int code = conn.getResponseCode();
                    if (code < 200 || code >= 300) {
                        throw new Exception("HTTP " + code);
                    }

                    InputStream is = conn.getInputStream();
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] chunk = new byte[8192];
                    int n;
                    while ((n = is.read(chunk)) != -1) buffer.write(chunk, 0, n);
                    is.close();
                    byte[] bytes = buffer.toByteArray();

                    new Handler(Looper.getMainLooper()).post(() -> {
                        try {
                            writeBytesToDownloads(reqId, bytes, filename, mimeType);
                        } catch (Exception e) {
                            Log.e(TAG, "saveFileFromUrl write error", e);
                            notifyDownloadResult(reqId, false, safeMsg(e));
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "saveFileFromUrl download error", e);
                    final String msg = safeMsg(e);
                    new Handler(Looper.getMainLooper()).post(() -> notifyDownloadResult(reqId, false, msg));
                } finally {
                    if (conn != null) conn.disconnect();
                }
            });
        }

        @JavascriptInterface
        public void downloadAndInstallApk(String url) {
            new Handler(Looper.getMainLooper()).post(() -> startApkDownload(url));
        }
    }

    private long updateDownloadId = -1;
    private final android.content.BroadcastReceiver downloadReceiver = new android.content.BroadcastReceiver() {
        @Override
        public void onReceive(android.content.Context context, Intent intent) {
            long id = intent.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (id == updateDownloadId) {
                installDownloadedApk();
            }
        }
    };

    private void startApkDownload(String url) {
        try {
            android.app.DownloadManager dm = (android.app.DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            android.app.DownloadManager.Request request = new android.app.DownloadManager.Request(Uri.parse(url));
            request.setTitle("Mise a jour Studiora");
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "studiora_update.apk");
            request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            updateDownloadId = dm.enqueue(request);
            runJs("window.onApkUpdateStatus && window.onApkUpdateStatus('downloading');");
        } catch (Exception e) {
            Log.e(TAG, "startApkDownload error", e);
            runJs("window.onApkUpdateStatus && window.onApkUpdateStatus('error');");
        }
    }

    private void installDownloadedApk() {
        try {
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "studiora_update.apk");
            Uri apkUri = androidx.core.content.FileProvider.getUriForFile(
                this, getPackageName() + ".fileprovider", file);
            Intent installIntent = new Intent(Intent.ACTION_VIEW);
            installIntent.setDataAndType(apkUri, "application/vnd.android.package-archive");
            installIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(installIntent);
            runJs("window.onApkUpdateStatus && window.onApkUpdateStatus('ready');");
        } catch (Exception e) {
            Log.e(TAG, "installDownloadedApk error", e);
            runJs("window.onApkUpdateStatus && window.onApkUpdateStatus('error');");
        }
    }

    private void writeBytesToDownloads(String reqId, byte[] bytes, String filename, String mimeType) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri item = getContentResolver().insert(collection, values);
                if (item == null) {
                    notifyDownloadResult(reqId, false, "insert_failed");
                    return;
                }
                OutputStream out = getContentResolver().openOutputStream(item);
                if (out != null) { out.write(bytes); out.close(); }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(item, values, null, null);
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    notifyDownloadResult(reqId, false, "permission_stockage_refusee");
                    return;
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, filename);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(bytes);
                fos.close();
            }
            notifyDownloadResult(reqId, true, filename);
        } catch (Exception e) {
            Log.e(TAG, "writeBytesToDownloads error", e);
            notifyDownloadResult(reqId, false, safeMsg(e));
        }
    }

    private void notifyDownloadResult(String reqId, boolean success, String info) {
        String safeReqId = reqId != null ? reqId.replace("'", "\\'") : "";
        String safeInfo = info != null ? info.replace("'", "\\'") : "";
        runJs("window.onAndroidDownloadResult && window.onAndroidDownloadResult('"
                + safeReqId + "', " + success + ", '" + safeInfo + "');");
    }

    private String safeMsg(Exception e) {
        return e.getMessage() != null ? e.getMessage() : "error";
    }

    private void ensureLocalCopyFromAssets() {
        File dir = new File(getFilesDir(), "www-live");
        File index = new File(dir, "index.html");
        android.content.SharedPreferences prefs = getSharedPreferences("studiora_native", MODE_PRIVATE);
        int lastCopiedVersion = prefs.getInt("last_bundled_asset_version", -1);
        // BUGFIX (2026-09-11, v2) : BuildConfig.VERSION_CODE ne compile pas
        // dans ce projet (buildFeatures.buildConfig n'est pas active cote
        // Gradle) — on recupere le versionCode via PackageManager a la
        // place, qui marche toujours sans configuration Gradle
        // supplementaire.
        int currentVersion;
        try {
            currentVersion = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            currentVersion = -1;
        }
        // BUGFIX (2026-09-11) : avant, on ne recopiait les assets embarqués
        // vers www-live QUE si aucun fichier n'existait encore là — donc une
        // MISE À JOUR de l'app (installer un nouvel APK par-dessus l'ancien,
        // sans désinstallation complète) ne rafraîchissait JAMAIS le contenu
        // local : l'ancienne copie de www-live (créée à l'installation
        // précédente, ou par un rafraîchissement silencieux antérieur)
        // restait chargée indéfiniment, même si le nouvel APK embarquait un
        // HTML plus récent avec des correctifs. On recopie donc maintenant
        // aussi quand le versionCode de l'APK a changé depuis la dernière
        // copie, pour que chaque nouvel APK installé démarre bien sur son
        // propre contenu à jour.
        if (index.exists() && lastCopiedVersion == currentVersion) return;
        try {
            if (!dir.exists()) dir.mkdirs();
            InputStream is = getAssets().open("public/index.html");
            FileOutputStream fos = new FileOutputStream(index);
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
            is.close();
            fos.close();
            prefs.edit().putInt("last_bundled_asset_version", currentVersion).apply();
            Log.i(TAG, "Copie des assets embarques vers le stockage modifiable (version " + currentVersion + ")");
        } catch (Exception e) {
            Log.e(TAG, "ensureLocalCopyFromAssets error", e);
        }
    }

    private boolean isNetworkAvailable() {
        try {
            android.net.ConnectivityManager cm =
                (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            android.net.NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return false;
        }
    }

    private void silentlyRefreshLiveCopy() {
        if (!isNetworkAvailable()) return;
        downloadExecutor.execute(this::downloadLiveCopyOnce);
    }

    // BUGFIX (2026-09-10) : extrait de silentlyRefreshLiveCopy() pour être
    // réutilisable par le bouton "Forcer la mise à jour du contenu" côté JS.
    // Avant ce correctif, ce bouton se contentait de NAVIGUER vers
    // studiora-education.netlify.app (une origine complètement différente,
    // sans le compte/la session en cours) sans jamais toucher au fichier
    // local (www-live/index.html) que l'app recharge à chaque ouverture —
    // donc la mise à jour "marchait" à l'écran, mais disparaissait dès la
    // fermeture/réouverture de l'app, qui rechargeait l'ancien fichier resté
    // intact sur le disque.
    private boolean downloadLiveCopyOnce() {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(LIVE_INDEX_URL + "?t=" + System.currentTimeMillis());
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("GET");
            conn.connect();
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

            InputStream is = conn.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while ((n = is.read(chunk)) != -1) buffer.write(chunk, 0, n);
            is.close();
            byte[] bytes = buffer.toByteArray();

            if (bytes.length < 1024) {
                Log.w(TAG, "Reponse suspecte (" + bytes.length + " octets), mise a jour ignoree");
                return false;
            }

            File dir = new File(getFilesDir(), "www-live");
            if (!dir.exists()) dir.mkdirs();
            File tmp = new File(dir, "index.html.tmp");
            FileOutputStream fos = new FileOutputStream(tmp);
            fos.write(bytes);
            fos.close();

            File index = new File(dir, "index.html");
            if (!tmp.renameTo(index)) {
                Log.w(TAG, "Echec du remplacement atomique de index.html");
                return false;
            }
            Log.i(TAG, "Copie locale mise a jour depuis GitHub Pages (" + bytes.length + " octets)");
            return true;
        } catch (Exception e) {
            Log.w(TAG, "downloadLiveCopyOnce: " + safeMsg(e));
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // BUGFIX (2026-09-10) : pont JS exposé sous "AndroidUpdater" — télécharge
    // réellement la dernière copie ET recharge la WebView sur cette copie
    // fraîchement écrite, sur la MÊME origine (appassets.androidplatform.net)
    // que l'app utilise normalement, pour ne pas perdre la session/le
    // compte connecté comme le faisait l'ancien bouton.
    private class UpdaterInterface {
        @JavascriptInterface
        public void forceRefreshNow() {
            runJs("window.onContentUpdateStatus && window.onContentUpdateStatus('checking');");
            downloadExecutor.execute(() -> {
                boolean ok = downloadLiveCopyOnce();
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (ok && getBridge() != null && getBridge().getWebView() != null) {
                        getBridge().getWebView().clearCache(true);
                        getBridge().getWebView().loadUrl("https://" + ASSET_DOMAIN + "/live/index.html");
                    } else {
                        runJs("window.onContentUpdateStatus && window.onContentUpdateStatus('error');");
                    }
                });
            });
        }

        // AJOUT (2026-09-12) : propose directement depuis l'app d'épingler
        // le widget sur l'écran d'accueil, au lieu de laisser l'utilisateur
        // le chercher lui-même dans le sélecteur de widgets du système.
        // Nécessite Android 8.0 (API 26) minimum et un lanceur qui supporte
        // cette API — on vérifie les deux avant de tenter, et on prévient
        // proprement en JS si ce n'est pas possible plutôt que d'échouer en
        // silence.
        @JavascriptInterface
        public void requestPinWidget() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                runJs("window.onPinWidgetStatus && window.onPinWidgetStatus('unsupported');");
                return;
            }
            android.appwidget.AppWidgetManager awm = android.appwidget.AppWidgetManager.getInstance(MainActivity.this);
            android.content.ComponentName provider = new android.content.ComponentName(MainActivity.this, StudioraWidgetProvider.class);
            if (awm == null || !awm.isRequestPinAppWidgetSupported()) {
                runJs("window.onPinWidgetStatus && window.onPinWidgetStatus('unsupported');");
                return;
            }
            try {
                awm.requestPinAppWidget(provider, null, null);
            } catch (Exception e) {
                Log.w(TAG, "requestPinWidget: " + safeMsg(e));
                runJs("window.onPinWidgetStatus && window.onPinWidgetStatus('error');");
            }
        }
    }

    // AJOUT (2026-09-14) : enregistrement micro 100% natif (MediaRecorder),
    // utilisé UNIQUEMENT en repli quand navigator.mediaDevices.getUserMedia()
    // échoue dans la WebView — bug connu sur certains appareils où l'audio
    // brut n'est pas accessible depuis la page web malgré la permission
    // Android déjà accordée. Avant ce correctif, ce cas de figure retombait
    // sur l'écoute continue AndroidSTT (fiabilité très faible, coupures à
    // chaque redémarrage de segment) — désormais il retombe sur un vrai
    // enregistrement fichier, envoyé ensuite au MÊME pipeline Whisper que les
    // fichiers importés, pour une qualité identique.
    private class NativeRecorderInterface {
        @JavascriptInterface
        public void startRecording() {
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_CODE);
                runJs("window.onNativeRecordingError && window.onNativeRecordingError('permission_refusee');");
                return;
            }
            // MODIFIÉ (2026-09-19) : l'enregistrement tourne maintenant dans
            // TranscriptionRecordingService (foreground service) au lieu d'un
            // MediaRecorder tenu directement par l'Activity, pour continuer
            // même app en arrière-plan ou écran verrouillé — Android coupe
            // sinon l'accès au micro dès que l'Activity n'est plus au premier
            // plan. Démarrage/arrêt confirmés de façon asynchrone (voir
            // recordingStoppedReceiver / onResume) plutôt que synchrone ici.
            try {
                Intent svc = new Intent(MainActivity.this, TranscriptionRecordingService.class)
                        .setAction(TranscriptionRecordingService.ACTION_START);
                ContextCompat.startForegroundService(MainActivity.this, svc);
                runJs("window.onNativeRecordingStarted && window.onNativeRecordingStarted();");
            } catch (Exception e) {
                Log.w(TAG, "NativeRecorder.startRecording: " + safeMsg(e));
                runJs("window.onNativeRecordingError && window.onNativeRecordingError('start_failed');");
            }
        }

        @JavascriptInterface
        public void stopRecording() {
            Intent svc = new Intent(MainActivity.this, TranscriptionRecordingService.class)
                    .setAction(TranscriptionRecordingService.ACTION_STOP);
            startService(svc);
            // Pas de callback JS synchrone ici : la confirmation (fichier prêt
            // ou erreur) arrive via recordingStoppedReceiver dès que le
            // Service a fini de l'écrire.
        }

        @JavascriptInterface
        public void deleteRecording(String fileName) {
            try {
                if (fileName == null || nativeRecDir == null) return;
                File f = new File(nativeRecDir, fileName);
                if (f.exists()) f.delete();
            } catch (Exception e) {
                Log.w(TAG, "NativeRecorder.deleteRecording: " + safeMsg(e));
            }
        }
    }

    // AJOUT (2026-09-17) : pont JS "AndroidWidgetSync" — la WebView pousse ici
    // l'état du jour (arrosage) car le widget natif ne peut pas lire le
    // localStorage/IndexedDB de la page. Écrit dans une SharedPreferences
    // dédiée (lue par StudioraWidgetProvider) puis force un rafraîchissement
    // immédiat du widget au lieu d'attendre le prochain cycle périodique.
    private class WidgetSyncInterface {
        @JavascriptInterface
        public void setState(String state) {
            if (state == null) return;
            if (!state.equals("todo") && !state.equals("done") && !state.equals("sick") && !state.equals("bravo")) return;
            SharedPreferences prefs = getSharedPreferences(StudioraWidgetProvider.PREFS_NAME, MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit()
                    .putString(StudioraWidgetProvider.KEY_STATE, state)
                    .putString(StudioraWidgetProvider.KEY_DATE, StudioraWidgetProvider.todayDateStr());
            if (state.equals("bravo")) editor.putLong(StudioraWidgetProvider.KEY_BRAVO_TS, System.currentTimeMillis());
            editor.apply();
            StudioraWidgetProvider.refreshAll(MainActivity.this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // AJOUT (2026-09-19) : rattrapage si l'enregistrement a été arrêté
        // (notification ou arrêt système) pendant que l'app n'était pas au
        // premier plan et n'a donc pas pu recevoir recordingStoppedReceiver.
        SharedPreferences prefs = getSharedPreferences(TranscriptionRecordingService.PREFS_NAME, MODE_PRIVATE);
        String file = prefs.getString(TranscriptionRecordingService.KEY_PENDING_FILE, null);
        String error = prefs.getString(TranscriptionRecordingService.KEY_PENDING_ERROR, null);
        if (file != null || error != null) {
            prefs.edit().remove(TranscriptionRecordingService.KEY_PENDING_FILE)
                    .remove(TranscriptionRecordingService.KEY_PENDING_ERROR).apply();
            if (file != null) {
                runJs("window.onNativeRecordingReady && window.onNativeRecordingReady(" + org.json.JSONObject.quote(file) + ");");
            } else {
                runJs("window.onNativeRecordingError && window.onNativeRecordingError(" + org.json.JSONObject.quote(error) + ");");
            }
        }
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(recordingStoppedReceiver); } catch (Exception ignored) {}
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            pendingIntent = getIntent();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_CODE);
            }

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
            }

            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    tts.setLanguage(new Locale("fr", "FR"));
                }
            });

            getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
                @Override
                public void handleOnBackPressed() {
                    handleBack();
                }
            });

            if (getBridge() != null && getBridge().getWebView() != null) {
                getBridge().getWebView().addJavascriptInterface(new WebAppInterface(), "AndroidTTS");
                getBridge().getWebView().addJavascriptInterface(new WebAppInterface(), "AndroidSTT");
                getBridge().getWebView().addJavascriptInterface(new DownloadInterface(), "AndroidDownload");
                getBridge().getWebView().addJavascriptInterface(new GoogleAuthInterface(), "AndroidGoogleAuth");
                getBridge().getWebView().addJavascriptInterface(new UpdaterInterface(), "AndroidUpdater");
                getBridge().getWebView().addJavascriptInterface(new NativeRecorderInterface(), "AndroidRecorder");
                getBridge().getWebView().addJavascriptInterface(new WidgetSyncInterface(), "AndroidWidgetSync");
                androidx.core.content.ContextCompat.registerReceiver(
                    this, downloadReceiver,
                    new android.content.IntentFilter(android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                    androidx.core.content.ContextCompat.RECEIVER_EXPORTED
                );
                // AJOUT (2026-09-19) : reçoit la confirmation de TranscriptionRecordingService
                // (fichier prêt ou erreur) même si l'enregistrement a été arrêté depuis la
                // notification pendant que l'app était en arrière-plan.
                androidx.core.content.ContextCompat.registerReceiver(
                    this, recordingStoppedReceiver,
                    new android.content.IntentFilter(TranscriptionRecordingService.ACTION_STOPPED_BROADCAST),
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                );

                getBridge().getWebView().setWebChromeClient(new WebChromeClient() {
                    @Override
                    public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                        if (mFilePathCallback != null) {
                            mFilePathCallback.onReceiveValue(null);
                        }
                        mFilePathCallback = filePathCallback;
                        try {
                            Intent intent = fileChooserParams.createIntent();
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            startActivityForResult(intent, FILE_CHOOSER_RESULT_CODE);
                        } catch (Exception e) {
                            Log.e(TAG, "onShowFileChooser error", e);
                            mFilePathCallback = null;
                            return false;
                        }
                        return true;
                    }

                    @Override
                    public void onPermissionRequest(final PermissionRequest request) {
                        runOnUiThread(() -> {
                            try {
                                boolean needsAudio = false;
                                for (String res : request.getResources()) {
                                    if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) needsAudio = true;
                                }
                                if (needsAudio && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                                        != PackageManager.PERMISSION_GRANTED) {
                                    request.deny();
                                    return;
                                }
                                request.grant(request.getResources());
                            } catch (Exception e) {
                                Log.e(TAG, "onPermissionRequest error", e);
                                request.deny();
                            }
                        });
                    }
                });

                ensureLocalCopyFromAssets();

                File liveDir = new File(getFilesDir(), "www-live");
                // AJOUT (2026-09-14) : dossier servi pour que la page web puisse récupérer
                // (via fetch) un enregistrement audio fait par le micro NATIF — voir
                // NativeRecorderInterface plus bas, utilisé quand getUserMedia() échoue
                // dans la WebView (bug connu sur certains appareils/versions).
                File recDir = new File(getFilesDir(), "native-recordings");
                if (!recDir.exists()) recDir.mkdirs();
                nativeRecDir = recDir;
                WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                        .setDomain(ASSET_DOMAIN)
                        .addPathHandler("/live/", new WebViewAssetLoader.InternalStoragePathHandler(this, liveDir))
                        .addPathHandler("/rec/", new WebViewAssetLoader.InternalStoragePathHandler(this, recDir))
                        .build();

                getBridge().getWebView().setWebViewClient(new WebViewClientCompat() {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        return assetLoader.shouldInterceptRequest(request.getUrl());
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        String scheme = request.getUrl().getScheme();
                        if (scheme != null && !scheme.equals("http") && !scheme.equals("https")) {
                            try {
                                Intent intent = Intent.parseUri(request.getUrl().toString(), Intent.URI_INTENT_SCHEME);
                                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                intent.setComponent(null);
                                intent.setSelector(null);
                                startActivity(intent);
                            } catch (Exception e) {
                                Log.w(TAG, "Impossible d'ouvrir l'app de paiement (" + scheme + ")", e);
                                toast("Application de paiement introuvable sur cet appareil.");
                            }
                            return true;
                        }
                        return false;
                    }
                });

                File liveIndex = new File(liveDir, "index.html");
                if (liveIndex.exists()) {
                    getBridge().getWebView().loadUrl("https://" + ASSET_DOMAIN + "/live/index.html");
                }
                silentlyRefreshLiveCopy();

                getBridge().getWebView().postDelayed(() -> {
                    try { handleShareIntent(pendingIntent); }
                    catch (Exception e) { Log.e(TAG, "share intent error", e); }
                }, 1200);
            }

        } catch (Exception e) {
            Log.e(TAG, "onCreate error", e);
        }
    }

    private void runJs(String js) {
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().post(() -> getBridge().getWebView().evaluateJavascript(js, null));
        }
    }

    // Correctif natif langues : accepte désormais une locale BCP47 optionnelle
    // (ex. "en-US") pour reconnaître la voix dans la langue cible au lieu du
    // français fixe. `lang` null ou vide → comportement inchangé (français).
    private void startNativeListening(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            runJs("window.onAndroidSTTError && window.onAndroidSTTError('unavailable');");
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            runJs("window.onAndroidSTTError && window.onAndroidSTTError('permission_refusee');");
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_CODE);
            return;
        }

        cancelSttTimeout();
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
        }

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    runJs("window.onAndroidSTTStart && window.onAndroidSTTStart();");
                }

                @Override public void onResults(Bundle results) {
                    cancelSttTimeout();
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String text = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                    text = text.replace("\n", " ").replace("\r", " ");
                    runJs("window.onAndroidSTTResult && window.onAndroidSTTResult('"
                        + text.replace("\\", "\\\\").replace("'", "\\'") + "');");
                }
                @Override public void onError(int error) {
                    cancelSttTimeout();
                    runJs("window.onAndroidSTTError && window.onAndroidSTTError('" + error + "');");
                }
                @Override public void onEndOfSpeech() {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
        }

        String recogLang = (lang != null && !lang.trim().isEmpty()) ? lang : "fr-FR";
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, recogLang);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try {
            speechRecognizer.startListening(intent);
            armSttTimeout();
        } catch (Exception e) {
            runJs("window.onAndroidSTTError && window.onAndroidSTTError('start_failed');");
        }
    }

    private void armSttTimeout() {
        cancelSttTimeout();
        sttTimeoutHandler = new Handler(Looper.getMainLooper());
        sttTimeoutRunnable = () -> {
            if (speechRecognizer != null) {
                try { speechRecognizer.cancel(); } catch (Exception ignored) {}
            }
            runJs("window.onAndroidSTTError && window.onAndroidSTTError('timeout');");
        };
        sttTimeoutHandler.postDelayed(sttTimeoutRunnable, STT_TIMEOUT_MS);
    }

    private void cancelSttTimeout() {
        if (sttTimeoutHandler != null && sttTimeoutRunnable != null) {
            sttTimeoutHandler.removeCallbacks(sttTimeoutRunnable);
        }
    }

    private void handleBack() {
        if (getBridge() != null && getBridge().getWebView() != null) {
            WebView wv = getBridge().getWebView();
            String currentUrl = wv.getUrl();
            boolean onForeignPage = currentUrl != null
                    && !currentUrl.contains(ASSET_DOMAIN)
                    && !currentUrl.startsWith("file:");
            if (onForeignPage && wv.canGoBack()) {
                wv.goBack();
                return;
            }
            wv.evaluateJavascript(
                "(function() { try { return !!(window.onAndroidBackPressed && window.onAndroidBackPressed()); } catch(e){ return false; } })();",
                value -> {
                    boolean handledByJs = "true".equals(value);
                    if (!handledByJs) {
                        if (wv.canGoBack()) {
                            wv.goBack();
                        } else {
                            finish();
                        }
                    }
                }
            );
        } else {
            finish();
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        try {
            setIntent(intent);
            handleShareIntent(intent);
        } catch (Exception e) { Log.e(TAG, "onNewIntent error", e); }
    }

    @Override
    public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (speechRecognizer != null) { speechRecognizer.destroy(); }
        downloadExecutor.shutdown();
        try { unregisterReceiver(downloadReceiver); } catch (Exception e) { /* deja desenregistre */ }
        super.onDestroy();
    }

    private ValueCallback<Uri[]> mFilePathCallback;
    private static final int FILE_CHOOSER_RESULT_CODE = 10001;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_GOOGLE_SIGN_IN) {
            try {
                com.google.android.gms.auth.api.signin.GoogleSignInAccount account =
                        GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                String idToken = account != null ? account.getIdToken() : null;
                if (idToken != null) {
                    postGoogleAuthResult(idToken, true, null);
                } else {
                    postGoogleAuthResult(null, false, "no_id_token");
                }
            } catch (ApiException e) {
                Log.e(TAG, "Google sign-in error", e);
                postGoogleAuthResult(null, false, "code_" + e.getStatusCode());
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            if (mFilePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            try {
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{ data.getData() };
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "onActivityResult file chooser error", e);
            }
            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

private void handleShareIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null && type.startsWith("image/")) {
            Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (imageUri != null) sendImageToWebView(imageUri, type);
        }
    }

    private void sendImageToWebView(Uri uri, String mimeType) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int n;
            while ((n = is.read(chunk)) != -1) buffer.write(chunk, 0, n);
            is.close();
            String base64 = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
            String fileName = getFileName(uri);
            String js = "window.receiveSharedImage && window.receiveSharedImage('"
                + base64 + "', '" + mimeType + "', '" + fileName.replace("'", "\\'") + "');";
            runJs(js);
        } catch (Exception e) { Log.e(TAG, "sendImageToWebView error", e); }
    }

    private String getFileName(Uri uri) {
        String result = "image.jpg";
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            try {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx != -1 && cursor.moveToFirst()) result = cursor.getString(idx);
            } finally { cursor.close(); }
        }
        return result;
    }
}
